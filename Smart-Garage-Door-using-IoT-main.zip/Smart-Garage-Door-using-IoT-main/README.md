# Smart-Garage-Door-using-IoT

![Screenshot 2024-03-02 141951](https://github.com/saivarshith18/Smart-Garage-Door-using-IoT/assets/139994815/097b9d74-894c-4844-a31a-8cab1072a646)
![Screenshot 2024-03-02 142039](https://github.com/saivarshith18/Smart-Garage-Door-using-IoT/assets/139994815/1efb429f-0a9b-47b4-9361-76c82219bd81)
